{
    "name": "HR Attendance Kiosk Limit",
    "version": "1.0",
    "category": "Human Resources",
    "summary": "Limits Kiosk Mode Check-in and Check-out by time",
    "author": "Custom",
    "depends": ["hr_attendance"],
    "data": [],
    "installable": True,
    "application": False,
    "auto_install": False
}
